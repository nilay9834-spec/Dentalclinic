import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
async function main(){
 const settings = { clinicName:"SmileCare Dental Clinic", phone:"+91 98765 43210", whatsapp:"919876543210", address:"123, Scheme No. 54, Indore, Madhya Pradesh", hours:"Mon–Sat: 9:00 AM–8:00 PM | Sun: 10:00 AM–2:00 PM", showReviews:"false", showGallery:"false" };
 for (const [key,value] of Object.entries(settings)) await db.siteSetting.upsert({where:{key},update:{value},create:{key,value}});
}
main().finally(()=>db.$disconnect());
