import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";
const secret = new TextEncoder().encode(process.env.SESSION_SECRET || "development-secret-change-me-please-123456");
const COOKIE = "smilecare_admin";
export async function createSession(){ return new SignJWT({role:"admin"}).setProtectedHeader({alg:"HS256"}).setIssuedAt().setExpirationTime("8h").sign(secret); }
export async function isAdmin(){ try { const token=(await cookies()).get(COOKIE)?.value; if(!token)return false; const {payload}=await jwtVerify(token,secret); return payload.role==="admin"; } catch{return false;} }
export const sessionCookieName=COOKIE;
