# SmileCare Dental Clinic — full-stack demo

A responsive dental-clinic website starter built from the supplied **Dental Clinic Website Playbook: Indore Edition**. Includes public pages, service detail routes, appointment request storage, protected admin dashboard, CSV export, metadata, privacy/terms templates and deployment notes.

> **Demo only:** SmileCare, clinic address, phone, opening hours, imagery and all profile content are placeholders. Replace and verify them with the actual clinic. The dentist must approve all credentials, clinical copy, claims, imagery and compliance decisions before launch. Reviews and patient galleries are intentionally not implemented/enabled by default.

## Stack
- Next.js App Router + TypeScript
- Tailwind CSS v4 (plus a custom responsive design system)
- Prisma ORM + PostgreSQL
- Zod validation
- Signed HTTP-only admin session cookie (HS256)

## Run locally
1. Install Node.js 20.9+ and PostgreSQL.
2. Copy `.env.example` to `.env` and set `DATABASE_URL`, `SESSION_SECRET`, `ADMIN_EMAIL`, and a strong `ADMIN_PASSWORD`.
3. Install dependencies: `npm install`
4. Generate Prisma client and create tables: `npx prisma generate && npx prisma db push`
5. Optional demo settings seed: `npm run db:seed`
6. Start: `npm run dev`
7. Open `http://localhost:3000`; admin: `/admin/login`.

## Admin
Set `ADMIN_EMAIL` and `ADMIN_PASSWORD` in the server environment. The login API compares these server-side and creates an HTTP-only, secure-in-production, eight-hour signed session. Change the default credentials before deployment. Do not commit `.env`.

## Appointment flow
The form collects name, Indian mobile number, concern, preferred day/time and explicit consent. It does not ask for medical history. Requests are stored in PostgreSQL and shown in `/admin`. Staff can update status, add an internal note and export CSV. The current build does **not** send email or WhatsApp notifications; those integrations require SMTP/provider credentials and should be added only after the clinic chooses a provider and tests consent and delivery.

## Deploy independently
1. Push this folder to a private or public GitHub repository.
2. Create a managed PostgreSQL database (Neon, Supabase, Render PostgreSQL or another provider).
3. Deploy to Vercel, Render, Railway or another Node.js host. Use `npm run build` and `npm start`.
4. Add all environment variables from `.env.example` to the host. Set `NEXT_PUBLIC_SITE_URL` to the final HTTPS domain.
5. Run `npx prisma db push` as a one-time deployment step (or use Prisma migrations for a controlled production workflow).
6. Add the verified Google Maps embed URL to `GOOGLE_MAPS_EMBED_URL`; update the map/directions links and contact details in the UI to the clinic's real details.
7. Connect the domain, test forms/admin on a real Android phone, verify metadata and rendered page source, run PageSpeed Insights, then submit the sitemap.

## Before launch checklist
- Replace demo name, address, phone, hours, map and WhatsApp number.
- Add only real clinic photos with usage rights and written consent for identifiable people.
- Verify dentist's recognised qualifications and State Dental Council registration details.
- Dentist to review all service copy and approve every clinical statement.
- Have a lawyer review Privacy Policy, Terms, consent wording, retention and grievance contact under applicable Indian law.
- Keep reviews/testimonials and before/after images disabled unless the dentist has confirmed current professional rules with the relevant State Dental Council. The supplied playbook flags the 14 October 2026 NDC advisory as a risk; this project takes the conservative default.
- Configure SMTP/provider notifications if required; none are active in this starter.
- Add rate limiting at the hosting/WAF layer before public launch. Honeypot and server-side validation are included, but are not a complete anti-abuse system.
- Use a strong unique admin password and rotate `SESSION_SECRET`.

## Playbook implementation notes
The site includes the playbook's mobile-first sticky navigation, call/WhatsApp contact affordances, service hub and service pages, doctor/clinic/FAQ/contact/booking/privacy/terms pages, lead dashboard, basic structured page metadata and a conservative review/gallery posture. The booking dashboard uses a compact request form and status workflow.

Not yet included: Google Business Profile API, Places API live reviews, review QR generator, blog CMS, Hindi translations, GA4/consent manager, automatic email/WhatsApp sending, advanced rate limiting, comprehensive schema JSON-LD, and a real admin-managed clinic profile editor. These are phase-two integrations and require real clinic credentials, legal review or provider choices.
